﻿using Microsoft.AspNetCore.Mvc;

namespace ProyectoMiniMarck.Areas.Empleado.Controllers
{
    [Area("Empleado")]
    public class InicioController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
    }
}
