﻿using Microsoft.AspNetCore.Mvc;

namespace MiniMarck_Version_2_.Areas.Empleado.Controllers
{
    [Area("Empleado")]
    public class InformeController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
    }
}
