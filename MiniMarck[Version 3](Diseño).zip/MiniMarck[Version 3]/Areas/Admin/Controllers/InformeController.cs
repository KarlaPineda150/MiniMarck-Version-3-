﻿using Microsoft.AspNetCore.Mvc;
using MiniMarck.AccesoDatos.Data.Repository;
using MiniMarck.AccesoDatos.Data.Repository.IRepository;
using MiniMarck.Models;
using MiniMarck.Models.ViewModels;
using MiniMarck_Version_3_.Data;

namespace MiniMarck_Version_2_.Areas.Admin.Controllers
{
    [Area("Admin")]
    public class InformeController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
    }
}
