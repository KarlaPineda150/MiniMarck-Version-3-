﻿using Microsoft.AspNetCore.Mvc;

namespace MiniMarck_Version_2_.Areas.Login.Controllers
{
    [Area("Login")]
    public class LoginsController : Controller
    {
        // Vista principal del login
        public IActionResult Index()
        {
            return View();
        }

        // Vista del login del administrador
        public IActionResult AdminLogin()
        {
            return View();
        }

        // Verificación simple de admin
        [HttpPost]
        public IActionResult AuthenticateAdmin(string username, string password)
        {
            if (username == "Admin" && password == "1234")
                return RedirectToAction("Index", "Inicio", new { area = "Admin" });

            ViewBag.Error = "Credenciales incorrectas";
            return View("AdminLogin");
        }

        // Redirección simple a Empleado (sin lógica de validación)
        [HttpPost]
        public IActionResult IrAEmpleado()
        {
            return RedirectToAction("Index", "Inicio", new { area = "Empleado" });
        }
    }
}
